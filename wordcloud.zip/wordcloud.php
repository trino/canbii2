<!DOCTYPE html>
<meta charset="utf-8">
<title>Word Cloud Generator</title>
<style>
	body {
	  position: relative;
	  font-family: "Helvetica Neue", sans-serif;
	  width: 960px;
	  margin: auto;
	  margin-bottom: 1em;
	  margin-top: 20px;
	}
	#presets a { border-left: solid #666 1px; padding: 0 10px; }
	#presets a.first { border-left: none; }
	#keyword { width: 300px; }
	#fetcher { width: 500px; }
	#keyword, #go { font-size: 1.5em; }
	#text { width: 100%; height: 100px; }
	p.copy { font-size: small; }
	#form { font-size: small; position: relative; }
	hr { border: none; border-bottom: solid #ccc 1px; }
	a.active { text-decoration: none; color: #000; font-weight: bold; cursor: text; }
	#angles line, #angles path, #angles circle { stroke: #666; }
	#angles text { fill: #333; }
	#angles path.drag { fill: #666; cursor: move; }
	#angles { text-align: center; margin: 0 auto; width: 350px; }
	#angles input, #max { width: 42px; }
	#canvasImg, #vis{border: 2px solid red;}
	.col-md-3{
		width: 25%;
	}
</style>

<?php 
	$currentURL = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? "https" : "http") . "://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
	
	function left($text, $length){
		return substr($text, 0, $length);
	}
	function right($text, $length){
		return substr($text, -$length);
	}
	function mid($text, $start, $length){
		return substr($text, $start, $length);
	}
	function endswith($text, $endswith){
		return strtolower(right($text, strlen($endswith))) == strtolower($endswith);
	}
	function removetail($text, $endswith, $words = false){
		if(endswith($text, $endswith)){
			$singular = left($text, strlen($text) - strlen($endswith));
			if(is_array($words)){
				if(in_array($singular, $words)){
					return $singular;
				} else {
					return $text;
				}
			}
			return $singular;
		}
		return $text;
	}

	function get($key, $default = false){
		if(isset($_GET[$key])){return $_GET[$key];}
		if(isset($_POST[$key])){return $_POST[$key];}
		return $default;
	}
	function checked($key, $default = false, $valuemustbe = true){
		$value = get($key, $default);
		if($value == $valuemustbe){
			return ' checked="checked"';
		}
	}
		
	$Text = get("text", 
"How the Word Cloud Generator Works

The layout algorithm for positioning words without overlap is available on GitHub under an open source license as d3-cloud. Note that this is the only the layout algorithm and any code for converting text into words and rendering the final output requires additional development.

As word placement can be quite slow for more than a few hundred words, the layout algorithm can be run asynchronously, with a configurable time step size. This makes it possible to animate words as they are placed without stuttering. It is recommended to always use a time step even without animations as it prevents the browser’s event loop from blocking while placing the words.

The layout algorithm itself is incredibly simple. For each word, starting with the most “important”:

Attempt to place the word at some starting point: usually near the middle, or somewhere on a central horizontal line.
If the word intersects with any previously placed words, move it one step along an increasing spiral. Repeat until no intersections are found.
The hard part is making it perform efficiently! According to Jonathan Feinberg, Wordle uses a combination of hierarchical bounding boxes and quadtrees to achieve reasonable speeds.

Glyphs in JavaScript

There isn’t a way to retrieve precise glyph shapes via the DOM, except perhaps for SVG fonts. Instead, we draw each word to a hidden canvas element, and retrieve the pixel data.

Retrieving the pixel data separately for each word is expensive, so we draw as many words as possible and then retrieve their pixels in a batch operation.

Sprites and Masks

My initial implementation performed collision detection using sprite masks. Once a word is placed, it doesn't move, so we can copy it to the appropriate position in a larger sprite representing the whole placement area.

The advantage of this is that collision detection only involves comparing a candidate sprite with the relevant area of this larger sprite, rather than comparing with each previous word separately.

Somewhat surprisingly, a simple low-level hack made a tremendous difference: when constructing the sprite I compressed blocks of 32 1-bit pixels into 32-bit integers, thus reducing the number of checks (and memory) by 32 times.

In fact, this turned out to beat my hierarchical bounding box with quadtree implementation on everything I tried it on (even very large areas and font sizes). I think this is primarily because the sprite version only needs to perform a single collision test per candidate area, whereas the bounding box version has to compare with every other previously placed word that overlaps slightly with the candidate area.

Another possibility would be to merge a word’s tree with a single large tree once it is placed. I think this operation would be fairly expensive though compared with the analagous sprite mask operation, which is essentially ORing a whole block.");

	$dueProcess = get("check-important", true);
	$originaltext = $Text;
	if($dueProcess){
		$skipwords = explode("|",  "i|me|my|myself|we|us|our|ours|ourselves|you|your|yours|yourself|yourselves|he|him|his|himself|she|her|hers|herself|it|its|itself|they|them|their|theirs|themselves|what|which|who|whom|whose|this|that|these|those|am|is|are|was|were|be|been|being|have|has|had|having|do|does|did|doing|will|would|should|can|could|ought|i'm|you're|he's|she's|it's|we're|they're|i've|you've|we've|they've|i'd|you'd|he'd|she'd|we'd|they'd|i'll|you'll|he'll|she'll|we'll|they'll|isn't|aren't|wasn't|weren't|hasn't|haven't|hadn't|doesn't|don't|didn't|won't|wouldn't|shan't|shouldn't|can't|cannot|couldn't|mustn't|let's|that's|who's|what's|here's|there's|when's|where's|why's|how's|a|an|the|and|but|if|or|because|as|until|while|of|at|by|for|with|about|against|between|into|through|during|before|after|above|below|to|from|up|upon|down|in|out|on|off|over|under|again|further|then|once|here|there|when|where|why|how|all|any|both|each|few|more|most|other|some|such|no|nor|not|only|own|same|so|than|too|very|say|says|said|shall");
		
		$Text = str_replace(["!", "@", "#", "%", ".", ",", ":", ";", '"', "“", "”", "\r\n", "(", ")", "    ", "   ", "  "], " ", strtolower($Text));
		$words = explode(" ", $Text);
		$wordlist = [];	
		$minlength = get("minlength", 4);
		$minquantity = get("minqty", 2);
		
		foreach($words as $index => $word){
			$word = trim($word);
			$word = removetail($word, "ing");
			$word = removetail($word, "ly");
			$word = removetail($word, "s", $words);
			
			$words[$index] = $word;
			if(in_array($word, $skipwords) || !$word || is_numeric($word) || strlen($word) < $minlength){
				unset($words[$index]);
			} else if(isset($wordlist[$word])) {
				$wordlist[$word]++;
			} else {
				$wordlist[$word] = 1;
			}
		}
		arsort($wordlist);
		//echo '<TABLE><TR><TH>Word</TH><TH>Qty</TH></TR>';
		$index = 0;
		$desiredwordcount = get("max", 250);
		$Text = "";
		foreach($wordlist as $word => $quantity){
			if($quantity < $minquantity){
				unset($wordlist[$word]);
			} else {
				$index++;
				if($index > $desiredwordcount){
					unset($wordlist[$word]);
				} else {
					//echo '<TR><TD>' . $word . '</TD><TD ALIGN="RIGHT">' . $quantity . '</TD></TR>';
					for($i=0; $i<$quantity; $i++){
						$Text .= $word . " ";
					}
				}
			}
		}
		//echo '<TR><TH>Total</TH><TH>' . count($wordlist) . '</TH></TABLE>';
		$Text = trim($Text);
	}
?>
<SCRIPT>
	var currentURL = "<?= $currentURL; ?>";
	function saveparameters(){
		var form = document.getElementById('form');
		form.action = currentURL;
		form.method = "post";
		form.submit();
	}
	function getselectvalue(ID){
		var e = document.getElementById(ID);
		return e.options [e.selectedIndex].text;
	}
	function changedfont(){
		var value = getselectvalue("fontlist");
		var e = document.getElementById("font");
		e.value = value;
	}
	function get(ID){
		var e = document.getElementById(ID);
		return e.value;
	}
	
	var alteredtext = false;
	function restoreoriginal(){
		if(!alteredtext){
			alteredtext = document.getElementById("text").value;
		}
		document.getElementById("text").value = document.getElementById("originaltext").value;
	}
	function restorealtered(){
		if(alteredtext){
			document.getElementById("text").value = alteredtext;
		}
	}
</SCRIPT>

<div id="vis"></div>

<form id="form">

	<p style="position: absolute; right: 0; top: 0" id="status"></p>

	<div style="text-align: center">
	  <div id="presets"></div>
	  <div id="custom-area">
		<?php 
			if($originaltext && $dueProcess){
				echo '<p><label>Original Text</label><p><textarea STYLE="width:960px;" ROWS="5" id="originaltext" name="originaltext">' . get("originaltext", $originaltext) . '</textarea>';
			}
		?>
		<p><label for="text">Paste your text below!</label>
		<p><textarea id="text" name="text"><?= $Text ?></textarea>
		<button id="go" type="submit">Preview</button>
		<button onclick="downloadPNG();" TITLE="the image will show below"> Generate PNG</button>
		<?php 
			if($originaltext && $dueProcess){
				echo ' <button onclick="restoreoriginal();"> Restore Original text</button> <button onclick="restorealtered();"> Revert back to altered text</button>';
			}
		?>
	  </div>
	</div>

	<hr>
	
	<DIV>
		<SPAN CLASS="col-md-3">
			<label for="check-important">
				<input type="checkbox" name="check-important" id="check-important" <?= checked("check-important", true); ?>> Pre-process important words</label>
		</SPAN>
		<SPAN CLASS="col-md-3">
			<input type="checkbox" name="minlength" id="minlength" <?= checked("minlength", 4); ?>> Minimum Word length
		</SPAN>
		<SPAN CLASS="col-md-3">
			<input type="checkbox" name="minqty" id="minqty" <?= checked("minqty", 2); ?>> Minimum Word quantity
		</SPAN>	
		<SPAN CLASS="col-md-3">
			<button onclick="saveparameters();">Save Parameters</button>
		</SPAN>
	</DIV>
	<HR>

	<div style="float: right; text-align: right">
		<p><label for="max">Number of words:</label> 
			<input type="number" name="max" value="<?= $desiredwordcount; ?>" min="1" id="max">
			
		<p><label for="per-line">
			<input type="checkbox" name="per-line" id="per-line" <?= checked("per-line"); ?>> One word per line</label>
			
		<p><label for="width">Width:
			<input type="number" name="width" ID="width" value="<?= get("width", 960); ?>" min="1" max="100000000">
		<p><label for="height">Height:
			<input type="number" name="height" ID="height" value="<?= get("height", 400); ?>" min="1" max="100000000">
			
		<!--p><label>Download:</label><button onclick="downloadSVG();">SVG</button-->
	</div>

	<div style="float: left">
		<p><label>Spiral:</label>
			<label for="archimedean"><input type="radio" name="spiral" id="archimedean" value="archimedean" <?= checked("spiral", "archimedean", "archimedean" ); ?>> Archimedean</label>
			<label for="rectangular"><input type="radio" name="spiral" id="rectangular" value="rectangular" <?= checked("spiral", "archimedean", "rectangular" ); ?>> Rectangular</label>
		
		<p><label for="scale">Scale:</label>
			<label for="scale-log"><input type="radio" name="scale" id="scale-log" value="log" <?= checked("scale", "log", "log" ); ?>> log n</label>
			<label for="scale-sqrt"><input type="radio" name="scale" id="scale-sqrt" value="sqrt" <?= checked("scale", "log", "sqrt" ); ?>> √n</label>
			<label for="scale-linear"><input type="radio" name="scale" id="scale-linear" value="linear" <?= checked("scale", "log", "linear" ); ?>> n</label>
		
		<p><label for="scale">Case:</label>
			<label for="scale-upper"><input type="radio" name="case" id="scale-upper" value="upper" <?= checked("case", "upper", "upper" ); ?>> upper</label>
			<label for="scale-lower"><input type="radio" name="case" id="scale-lower" value="lower" <?= checked("case", "upper", "lower" ); ?>> lower</label>
		
		<p><label for="font">Font:</label>
			<input type="text" id="font" name="font" value="<?= get("font", "Impact"); ?>" READONLY STYLE="display: none;">
			<SELECT ONCHANGE="changedfont();" ID="fontlist">
				<?php 
					$currentfont = get("font", "Impact");
					$fonts = ["Helvetica", "Arial", "Times", "Times New Roman", "Impact", "Courier", "Courier New", "Verdana", "Tahoma", "Arial Black", "Comic Sans MS", "Avant Garde", "Georgia", "Palatino", "Bookman", "Garamond", "Century Schoolbook", "Andale Mono"];
					sort($fonts);
					foreach($fonts as $font){
						echo '<OPTION';
						if($font == $currentfont){
							echo ' SELECTED';
						}
						echo '>' . $font . '</OPTION>';
					}
				?>
			</SELECT>
	</div>

	<div id="angles">
	  <p><input type="number" id="angle-count" value="5" min="1"> <label for="angle-count">orientations</label>
		<label for="angle-from">from</label> <input type="number" id="angle-from" name="angle-from" value="<?= get("angle-from", "-60"); ?>" min="-90" max="90"> °
		<label for="angle-to">to</label> <input type="number" id="angle-to" name="angle-to" value="<?= get("angle-to", "60"); ?>" min="-90" max="90"> °
	</div>
</form>

<script src="d3.min.js"></script>
<script src="cloud.min.js"></script>

<P><IMG ID="canvasImg" DOWNLOAD="wordcloud.png">